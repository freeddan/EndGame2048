#include "header.h"

/*
void print_matrix(int board[][4], SDL_Texture *square2, SDL_Renderer *renderer) {
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            if (board [0][0] == 2) {
                SDL_RenderCopy(renderer, square2, NULL, &square00);
            } 
        }


    }
}*/

