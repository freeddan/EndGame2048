#include "header.h"

void game(int board[][4], short empty_tiles, bool is_swapping) {
    empty_tiles = check_board(board);
    if (is_swapping) {
        generate_random(board, empty_tiles);
        empty_tiles--;
    }
   /* *score = check_score(board, *score);
    printf("%i\n", *score);*/
    // print_matrix(board);
    if (empty_tiles == 0) {
        if (can_swap(board) == false) {
            printf("You lose\n");
            return;
        }
    }
    printf("enter: w, d, s, a, e\n");
}
