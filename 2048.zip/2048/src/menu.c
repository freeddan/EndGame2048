#include "header.h"

bool menu(SDL_Renderer *renderer, bool running)
{

    SDL_Event event;

    SDL_Texture *background = IMG_LoadTexture(renderer, "resource/images/back.png");
    SDL_Texture *game_field = IMG_LoadTexture(renderer, "resource/images/2048back.png");
    SDL_Texture *exit_button = IMG_LoadTexture(renderer, "resource/images/exit.png");
    SDL_Texture *square2 = IMG_LoadTexture(renderer, "resource/images/2.png");
    SDL_Texture *square4 = IMG_LoadTexture(renderer, "resource/images/4.png");
    SDL_Texture *square8 = IMG_LoadTexture(renderer, "resource/images/8.png");
    SDL_Texture *square16 = IMG_LoadTexture(renderer, "resource/images/16.png");
    SDL_Texture *square322 = IMG_LoadTexture(renderer, "resource/images/32.png");
    SDL_Texture *square64 = IMG_LoadTexture(renderer, "resource/images/64.png");
    SDL_Texture *square128 = IMG_LoadTexture(renderer, "resource/images/128.png");
    SDL_Texture *square256 = IMG_LoadTexture(renderer, "resource/images/256.png");
    SDL_Texture *square512 = IMG_LoadTexture(renderer, "resource/images/512.png");
    SDL_Texture *square1024 = IMG_LoadTexture(renderer, "resource/images/1024.png");
    SDL_Texture *square2048 = IMG_LoadTexture(renderer, "resource/images/2048.png");

    SDL_Rect gamefield = {GAMEFIELD_X, GAMEFIELD_Y, 600, 570};
    SDL_Rect exit = {EXIT_X, EXIT_Y, 280, 60};
    
    square00.x = SQUARE1_X;
    square00.y = SQUARE1_Y;
    square00.w = 150;
    square00.h = 150;
    
    square01.x = SQUARE2_X;
    square01.y = SQUARE2_Y;
    square01.w = 150;
    square01.h = 150;

    square02.x = SQUARE3_X;
    square02.y = SQUARE3_Y;
    square02.w = 150;
    square02.h = 150;

    square03.x = SQUARE4_X;
    square03.y = SQUARE4_Y;
    square03.w = 150;
    square03.h = 150;

    square10.x = SQUARE5_X;
    square10.y = SQUARE5_Y;
    square10.w = 150;
    square10.h = 150;

    square11.x = SQUARE6_X;
    square11.y = SQUARE6_Y;
    square11.w = 150;
    square11.h = 150;

    square12.x = SQUARE7_X;
    square12.y = SQUARE7_Y;
    square12.w = 150;
    square12.h = 150;

    square13.x = SQUARE8_X;
    square13.y = SQUARE8_Y;
    square13.w = 150;
    square13.h = 150;
    
    square20.x = SQUARE9_X;
    square20.y = SQUARE9_Y;
    square20.w = 150;
    square20.h = 150;

    square21.x = SQUARE10_X;
    square21.y = SQUARE10_Y;
    square21.w = 150;
    square21.h = 150;

    square22.x = SQUARE11_X;
    square22.y = SQUARE11_Y;
    square22.w = 150;
    square22.h = 150;

    square23.x = SQUARE12_X;
    square23.y = SQUARE12_Y;
    square23.w = 150;
    square23.h = 150;

    square30.x = SQUARE13_X;
    square30.y = SQUARE13_Y;
    square30.w = 150;
    square30.h = 150;

    square31.x = SQUARE14_X;
    square31.y = SQUARE14_Y;
    square31.w = 150;
    square31.h = 150;

    square32.x = SQUARE15_X;
    square32.y = SQUARE15_Y;
    square32.w = 150;
    square32.h = 150;

    square33.x = SQUARE16_X;
    square33.y = SQUARE16_Y;
    square33.w = 150;
    square33.h = 150;


    int board[4][4] = {{0, 0, 0, 0},
                       {0, 0, 0, 0},
                       {0, 0, 0, 0},
                       {0, 0, 0, 0}};
    //char sym;
                short empty_tiles = 0;
            bool is_swapping = 0;
    generate_random(board, 16);
    while (running)
    {
        SDL_RenderClear(renderer);
        SDL_RenderCopy(renderer, background, NULL, NULL);
        SDL_RenderCopy(renderer, game_field, NULL, &gamefield);
        SDL_RenderCopy(renderer, exit_button, NULL, &exit);


        // short score = check_score(board, 0);
        // print_matrix(board, square2, renderer);

        while (SDL_PollEvent(&event))
        {
            SDL_RenderClear(renderer);
           
            

            switch (event.type) {

            case SDL_KEYDOWN:
            if(event.key.keysym.sym == SDLK_w) {
                is_swapping = vertical_swap(board, 1, 4, 0, 1);
                game(board, empty_tiles, is_swapping);
            } 
            if(event.key.keysym.sym == SDLK_d) {
                is_swapping = gorizontal_swap(board, 2, -1, 3, -1);
                game(board, empty_tiles, is_swapping);
            } 
            if(event.key.keysym.sym == SDLK_s) {
                is_swapping = vertical_swap(board, 2, -1, 3, -1);
                game(board, empty_tiles, is_swapping);
            } 
            if(event.key.keysym.sym == SDLK_a) {
                is_swapping = gorizontal_swap(board, 1, 4, 0, 1);
                game(board, empty_tiles, is_swapping);
            } 
             if(event.key.keysym.sym == SDLK_ESCAPE) {
                running = false;
            }

        
        
            case SDL_MOUSEBUTTONDOWN:

                if (event.button.button == SDL_BUTTON_LEFT 
                && event.button.x >= EXIT_X 
                && event.button.x <= EXIT_X + EXIT_SIZE_X 
                && event.button.y >= EXIT_Y 
                && event.button.y <= EXIT_Y + EXIT_SIZE_Y)
                {
                    running = false;
                }

                break;

            
            }
        }
        for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {

            // -------------------2---------------------
            if (board [0][0] == 2) {
                SDL_RenderCopy(renderer, square2, NULL, &square00);
            } 
            if(board[0][1] == 2){
                SDL_RenderCopy(renderer, square2, NULL, &square01);
            }
            if(board[0][2] == 2){
                SDL_RenderCopy(renderer, square2, NULL, &square02);
            }
            if(board[0][3] == 2){
                SDL_RenderCopy(renderer, square2, NULL, &square03);
            }

            if (board [1][0] == 2) {
                SDL_RenderCopy(renderer, square2, NULL, &square10);
            } 
            if(board[1][1] == 2){
                SDL_RenderCopy(renderer, square2, NULL, &square11);
            }
            if(board[1][2] == 2){
                SDL_RenderCopy(renderer, square2, NULL, &square12);
            }
            if(board[1][3] == 2){
                SDL_RenderCopy(renderer, square2, NULL, &square13);
            }

            if (board [2][0] == 2) {
                SDL_RenderCopy(renderer, square2, NULL, &square20);
            } 
            if(board[2][1] == 2){
                SDL_RenderCopy(renderer, square2, NULL, &square21);
            }
            if(board[2][2] == 2){
                SDL_RenderCopy(renderer, square2, NULL, &square22);
            }
            if(board[2][3] == 2){
                SDL_RenderCopy(renderer, square2, NULL, &square23);
            }

            if (board [3][0] == 2) {
                SDL_RenderCopy(renderer, square2, NULL, &square30);
            } 
            if(board[3][1] == 2){
                SDL_RenderCopy(renderer, square2, NULL, &square31);
            }
            if(board[3][2] == 2){
                SDL_RenderCopy(renderer, square2, NULL, &square32);
            }
            if(board[3][3] == 2){
                SDL_RenderCopy(renderer, square2, NULL, &square33);
            }

            // -------------------4---------------------

             if (board [0][0] == 4) {
                SDL_RenderCopy(renderer, square4, NULL, &square00);
            } 
            if(board[0][1] == 4){
                SDL_RenderCopy(renderer, square4, NULL, &square01);
            }
            if(board[0][2] == 4){
                SDL_RenderCopy(renderer, square4, NULL, &square02);
            }
            if(board[0][3] == 4){
                SDL_RenderCopy(renderer, square4, NULL, &square03);
            }

            if (board [1][0] == 4) {
                SDL_RenderCopy(renderer, square4, NULL, &square10);
            } 
            if(board[1][1] == 4){
                SDL_RenderCopy(renderer, square4, NULL, &square11);
            }
            if(board[1][2] == 4){
                SDL_RenderCopy(renderer, square4, NULL, &square12);
            }
            if(board[1][3] == 4){
                SDL_RenderCopy(renderer, square4, NULL, &square13);
            }

            if (board [2][0] == 4) {
                SDL_RenderCopy(renderer, square4, NULL, &square20);
            } 
            if(board[2][1] == 4){
                SDL_RenderCopy(renderer, square4, NULL, &square21);
            }
            if(board[2][2] == 4){
                SDL_RenderCopy(renderer, square4, NULL, &square22);
            }
            if(board[2][3] == 4){
                SDL_RenderCopy(renderer, square4, NULL, &square23);
            }

            if (board [3][0] == 4) {
                SDL_RenderCopy(renderer, square4, NULL, &square30);
            } 
            if(board[3][1] == 4){
                SDL_RenderCopy(renderer, square4, NULL, &square31);
            }
            if(board[3][2] == 4){
                SDL_RenderCopy(renderer, square4, NULL, &square32);
            }
            if(board[3][3] == 4){
                SDL_RenderCopy(renderer, square4, NULL, &square33);
            }

            // -------------------8---------------------

             if (board [0][0] == 8) {
                SDL_RenderCopy(renderer, square8, NULL, &square00);
            } 
            if(board[0][1] == 8){
                SDL_RenderCopy(renderer, square8, NULL, &square01);
            }
            if(board[0][2] == 8){
                SDL_RenderCopy(renderer, square8, NULL, &square02);
            }
            if(board[0][3] == 8){
                SDL_RenderCopy(renderer, square8, NULL, &square03);
            }

            if (board [1][0] == 8) {
                SDL_RenderCopy(renderer, square8, NULL, &square10);
            } 
            if(board[1][1] == 8){
                SDL_RenderCopy(renderer, square8, NULL, &square11);
            }
            if(board[1][2] == 8){
                SDL_RenderCopy(renderer, square8, NULL, &square12);
            }
            if(board[1][3] == 8){
                SDL_RenderCopy(renderer, square8, NULL, &square13);
            }

            if (board [2][0] == 8) {
                SDL_RenderCopy(renderer, square8, NULL, &square20);
            } 
            if(board[2][1] == 8){
                SDL_RenderCopy(renderer, square8, NULL, &square21);
            }
            if(board[2][2] == 8){
                SDL_RenderCopy(renderer, square8, NULL, &square22);
            }
            if(board[2][3] == 8){
                SDL_RenderCopy(renderer, square8, NULL, &square23);
            }

            if (board [3][0] == 8) {
                SDL_RenderCopy(renderer, square8, NULL, &square30);
            } 
            if(board[3][1] == 8){
                SDL_RenderCopy(renderer, square8, NULL, &square31);
            }
            if(board[3][2] == 8){
                SDL_RenderCopy(renderer, square8, NULL, &square32);
            }
            if(board[3][3] == 8){
                SDL_RenderCopy(renderer, square8, NULL, &square33);
            }

             // -------------------16---------------------

             if (board [0][0] == 16) {
                SDL_RenderCopy(renderer, square16, NULL, &square00);
            } 
            if(board[0][1] == 16){
                SDL_RenderCopy(renderer, square16, NULL, &square01);
            }
            if(board[0][2] == 16){
                SDL_RenderCopy(renderer, square16, NULL, &square02);
            }
            if(board[0][3] == 16){
                SDL_RenderCopy(renderer, square16, NULL, &square03);
            }

            if (board [1][0] == 16) {
                SDL_RenderCopy(renderer, square16, NULL, &square10);
            } 
            if(board[1][1] == 16){
                SDL_RenderCopy(renderer, square16, NULL, &square11);
            }
            if(board[1][2] == 16){
                SDL_RenderCopy(renderer, square16, NULL, &square12);
            }
            if(board[1][3] == 16){
                SDL_RenderCopy(renderer, square16, NULL, &square13);
            }

            if (board [2][0] == 16) {
                SDL_RenderCopy(renderer, square16, NULL, &square20);
            } 
            if(board[2][1] == 16){
                SDL_RenderCopy(renderer, square16, NULL, &square21);
            }
            if(board[2][2] == 16){
                SDL_RenderCopy(renderer, square16, NULL, &square22);
            }
            if(board[2][3] == 16){
                SDL_RenderCopy(renderer, square16, NULL, &square23);
            }

            if (board [3][0] == 16) {
                SDL_RenderCopy(renderer, square16, NULL, &square30);
            } 
            if(board[3][1] == 16){
                SDL_RenderCopy(renderer, square16, NULL, &square31);
            }
            if(board[3][2] == 16){
                SDL_RenderCopy(renderer, square16, NULL, &square32);
            }
            if(board[3][3] == 16){
                SDL_RenderCopy(renderer, square16, NULL, &square33);
            }

            // -------------------32---------------------

             if (board [0][0] == 32) {
                SDL_RenderCopy(renderer, square322, NULL, &square00);
            } 
            if(board[0][1] == 32){
                SDL_RenderCopy(renderer, square322, NULL, &square01);
            }
            if(board[0][2] == 32){
                SDL_RenderCopy(renderer, square322, NULL, &square02);
            }
            if(board[0][3] == 32){
                SDL_RenderCopy(renderer, square322, NULL, &square03);
            }

            if (board [1][0] == 32) {
                SDL_RenderCopy(renderer, square322, NULL, &square10);
            } 
            if(board[1][1] == 32){
                SDL_RenderCopy(renderer, square322, NULL, &square11);
            }
            if(board[1][2] == 32){
                SDL_RenderCopy(renderer, square322, NULL, &square12);
            }
            if(board[1][3] == 32){
                SDL_RenderCopy(renderer, square322, NULL, &square13);
            }

            if (board [2][0] == 32) {
                SDL_RenderCopy(renderer, square322, NULL, &square20);
            } 
            if(board[2][1] == 32){
                SDL_RenderCopy(renderer, square322, NULL, &square21);
            }
            if(board[2][2] == 32){
                SDL_RenderCopy(renderer, square322, NULL, &square22);
            }
            if(board[2][3] == 32){
                SDL_RenderCopy(renderer, square322, NULL, &square23);
            }

            if (board [3][0] == 32) {
                SDL_RenderCopy(renderer, square322, NULL, &square30);
            } 
            if(board[3][1] == 32){
                SDL_RenderCopy(renderer, square322, NULL, &square31);
            }
            if(board[3][2] == 32){
                SDL_RenderCopy(renderer, square322, NULL, &square32);
            }
            if(board[3][3] == 32){
                SDL_RenderCopy(renderer, square322, NULL, &square33);
            }

            // -------------------64---------------------

             if (board [0][0] == 64) {
                SDL_RenderCopy(renderer, square64, NULL, &square00);
            } 
            if(board[0][1] == 64){
                SDL_RenderCopy(renderer, square64, NULL, &square01);
            }
            if(board[0][2] == 64){
                SDL_RenderCopy(renderer, square64, NULL, &square02);
            }
            if(board[0][3] == 64){
                SDL_RenderCopy(renderer, square64, NULL, &square03);
            }

            if (board [1][0] == 64) {
                SDL_RenderCopy(renderer, square64, NULL, &square10);
            } 
            if(board[1][1] == 64){
                SDL_RenderCopy(renderer, square64, NULL, &square11);
            }
            if(board[1][2] == 64){
                SDL_RenderCopy(renderer, square64, NULL, &square12);
            }
            if(board[1][3] == 64){
                SDL_RenderCopy(renderer, square64, NULL, &square13);
            }

            if (board [2][0] == 64) {
                SDL_RenderCopy(renderer, square64, NULL, &square20);
            } 
            if(board[2][1] == 64){
                SDL_RenderCopy(renderer, square64, NULL, &square21);
            }
            if(board[2][2] == 64){
                SDL_RenderCopy(renderer, square64, NULL, &square22);
            }
            if(board[2][3] == 64){
                SDL_RenderCopy(renderer, square64, NULL, &square23);
            }

            if (board [3][0] == 64) {
                SDL_RenderCopy(renderer, square64, NULL, &square30);
            } 
            if(board[3][1] == 64){
                SDL_RenderCopy(renderer, square64, NULL, &square31);
            }
            if(board[3][2] == 64){
                SDL_RenderCopy(renderer, square64, NULL, &square32);
            }
            if(board[3][3] == 64){
                SDL_RenderCopy(renderer, square64, NULL, &square33);
            }
            // -------------------128---------------------

             if (board [0][0] == 128) {
                SDL_RenderCopy(renderer, square128, NULL, &square00);
            } 
            if(board[0][1] == 128){
                SDL_RenderCopy(renderer, square128, NULL, &square01);
            }
            if(board[0][2] == 128){
                SDL_RenderCopy(renderer, square128, NULL, &square02);
            }
            if(board[0][3] == 128){
                SDL_RenderCopy(renderer, square128, NULL, &square03);
            }

            if (board [1][0] == 128) {
                SDL_RenderCopy(renderer, square128, NULL, &square10);
            } 
            if(board[1][1] == 128){
                SDL_RenderCopy(renderer, square128, NULL, &square11);
            }
            if(board[1][2] == 128){
                SDL_RenderCopy(renderer, square128, NULL, &square12);
            }
            if(board[1][3] == 128){
                SDL_RenderCopy(renderer, square128, NULL, &square13);
            }

            if (board [2][0] == 128) {
                SDL_RenderCopy(renderer, square128, NULL, &square20);
            } 
            if(board[2][1] == 128){
                SDL_RenderCopy(renderer, square128, NULL, &square21);
            }
            if(board[2][2] == 128){
                SDL_RenderCopy(renderer, square128, NULL, &square22);
            }
            if(board[2][3] == 128){
                SDL_RenderCopy(renderer, square128, NULL, &square23);
            }

            if (board [3][0] == 128) {
                SDL_RenderCopy(renderer, square128, NULL, &square30);
            } 
            if(board[3][1] == 128){
                SDL_RenderCopy(renderer, square128, NULL, &square31);
            }
            if(board[3][2] == 128){
                SDL_RenderCopy(renderer, square128, NULL, &square32);
            }
            if(board[3][3] == 128){
                SDL_RenderCopy(renderer, square128, NULL, &square33);
            }
            // -------------------256---------------------

             if (board [0][0] == 256) {
                SDL_RenderCopy(renderer, square256, NULL, &square00);
            } 
            if(board[0][1] == 256){
                SDL_RenderCopy(renderer, square256, NULL, &square01);
            }
            if(board[0][2] == 256){
                SDL_RenderCopy(renderer, square256, NULL, &square02);
            }
            if(board[0][3] == 256){
                SDL_RenderCopy(renderer, square256, NULL, &square03);
            }

            if (board [1][0] == 256) {
                SDL_RenderCopy(renderer, square256, NULL, &square10);
            } 
            if(board[1][1] == 256){
                SDL_RenderCopy(renderer, square256, NULL, &square11);
            }
            if(board[1][2] == 256){
                SDL_RenderCopy(renderer, square256, NULL, &square12);
            }
            if(board[1][3] == 256){
                SDL_RenderCopy(renderer, square256, NULL, &square13);
            }

            if (board [2][0] == 256) {
                SDL_RenderCopy(renderer, square256, NULL, &square20);
            } 
            if(board[2][1] == 256){
                SDL_RenderCopy(renderer, square256, NULL, &square21);
            }
            if(board[2][2] == 256){
                SDL_RenderCopy(renderer, square256, NULL, &square22);
            }
            if(board[2][3] == 256){
                SDL_RenderCopy(renderer, square256, NULL, &square23);
            }

            if (board [3][0] == 256) {
                SDL_RenderCopy(renderer, square256, NULL, &square30);
            } 
            if(board[3][1] == 256){
                SDL_RenderCopy(renderer, square256, NULL, &square31);
            }
            if(board[3][2] == 256){
                SDL_RenderCopy(renderer, square256, NULL, &square32);
            }
            if(board[3][3] == 256){
                SDL_RenderCopy(renderer, square256, NULL, &square33);
            }
// -------------------512---------------------

             if (board [0][0] == 512) {
                SDL_RenderCopy(renderer, square512, NULL, &square00);
            } 
            if(board[0][1] == 512){
                SDL_RenderCopy(renderer, square512, NULL, &square01);
            }
            if(board[0][2] == 512){
                SDL_RenderCopy(renderer, square512, NULL, &square02);
            }
            if(board[0][3] == 512){
                SDL_RenderCopy(renderer, square512, NULL, &square03);
            }

            if (board [1][0] == 512) {
                SDL_RenderCopy(renderer, square512, NULL, &square10);
            } 
            if(board[1][1] == 512){
                SDL_RenderCopy(renderer, square512, NULL, &square11);
            }
            if(board[1][2] == 512){
                SDL_RenderCopy(renderer, square512, NULL, &square12);
            }
            if(board[1][3] == 512){
                SDL_RenderCopy(renderer, square512, NULL, &square13);
            }

            if (board [2][0] == 512) {
                SDL_RenderCopy(renderer, square512, NULL, &square20);
            } 
            if(board[2][1] == 512){
                SDL_RenderCopy(renderer, square512, NULL, &square21);
            }
            if(board[2][2] == 512){
                SDL_RenderCopy(renderer, square512, NULL, &square22);
            }
            if(board[2][3] == 512){
                SDL_RenderCopy(renderer, square512, NULL, &square23);
            }

            if (board [3][0] == 512) {
                SDL_RenderCopy(renderer, square512, NULL, &square30);
            } 
            if(board[3][1] == 512){
                SDL_RenderCopy(renderer, square512, NULL, &square31);
            }
            if(board[3][2] == 512){
                SDL_RenderCopy(renderer, square512, NULL, &square32);
            }
            if(board[3][3] == 512){
                SDL_RenderCopy(renderer, square512, NULL, &square33);
            }

            // -------------------1024---------------------

             if (board [0][0] == 1024) {
                SDL_RenderCopy(renderer, square1024, NULL, &square00);
            } 
            if(board[0][1] == 1024){
                SDL_RenderCopy(renderer, square1024, NULL, &square01);
            }
            if(board[0][2] == 1024){
                SDL_RenderCopy(renderer, square1024, NULL, &square02);
            }
            if(board[0][3] == 1024){
                SDL_RenderCopy(renderer, square1024, NULL, &square03);
            }

            if (board [1][0] == 1024) {
                SDL_RenderCopy(renderer, square1024, NULL, &square10);
            } 
            if(board[1][1] == 1024){
                SDL_RenderCopy(renderer, square1024, NULL, &square11);
            }
            if(board[1][2] == 1024){
                SDL_RenderCopy(renderer, square1024, NULL, &square12);
            }
            if(board[1][3] == 1024){
                SDL_RenderCopy(renderer, square1024, NULL, &square13);
            }

            if (board [2][0] == 1024) {
                SDL_RenderCopy(renderer, square1024, NULL, &square20);
            } 
            if(board[2][1] == 1024){
                SDL_RenderCopy(renderer, square1024, NULL, &square21);
            }
            if(board[2][2] == 1024){
                SDL_RenderCopy(renderer, square1024, NULL, &square22);
            }
            if(board[2][3] == 1024){
                SDL_RenderCopy(renderer, square1024, NULL, &square23);
            }

            if (board [3][0] == 1024) {
                SDL_RenderCopy(renderer, square1024, NULL, &square30);
            } 
            if(board[3][1] == 1024){
                SDL_RenderCopy(renderer, square1024, NULL, &square31);
            }
            if(board[3][2] == 1024){
                SDL_RenderCopy(renderer, square1024, NULL, &square32);
            }
            if(board[3][3] == 1024){
                SDL_RenderCopy(renderer, square1024, NULL, &square33);
            }
            // -------------------1024---------------------

             if (board [0][0] == 2048) {
                SDL_RenderCopy(renderer, square2048, NULL, &square00);
            } 
            if(board[0][1] == 2048){
                SDL_RenderCopy(renderer, square2048, NULL, &square01);
            }
            if(board[0][2] == 2048){
                SDL_RenderCopy(renderer, square2048, NULL, &square02);
            }
            if(board[0][3] == 2048){
                SDL_RenderCopy(renderer, square2048, NULL, &square03);
            }

            if (board [1][0] == 2048) {
                SDL_RenderCopy(renderer, square2048, NULL, &square10);
            } 
            if(board[1][1] == 2048){
                SDL_RenderCopy(renderer, square2048, NULL, &square11);
            }
            if(board[1][2] == 2048){
                SDL_RenderCopy(renderer, square2048, NULL, &square12);
            }
            if(board[1][3] == 2048){
                SDL_RenderCopy(renderer, square2048, NULL, &square13);
            }

            if (board [2][0] == 2048) {
                SDL_RenderCopy(renderer, square2048, NULL, &square20);
            } 
            if(board[2][1] == 2048){
                SDL_RenderCopy(renderer, square2048, NULL, &square21);
            }
            if(board[2][2] == 2048){
                SDL_RenderCopy(renderer, square2048, NULL, &square22);
            }
            if(board[2][3] == 2048){
                SDL_RenderCopy(renderer, square2048, NULL, &square23);
            }

            if (board [3][0] == 2048) {
                SDL_RenderCopy(renderer, square2048, NULL, &square30);
            } 
            if(board[3][1] == 2048){
                SDL_RenderCopy(renderer, square2048, NULL, &square31);
            }
            if(board[3][2] == 2048){
                SDL_RenderCopy(renderer, square2048, NULL, &square32);
            }
            if(board[3][3] == 2048){
                SDL_RenderCopy(renderer, square2048, NULL, &square33);
            }
        }

    }
        SDL_RenderPresent(renderer);
    }

    return 0;
}
